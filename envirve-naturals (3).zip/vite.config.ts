import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';
import { defineConfig, Plugin } from 'vite';
import JSZip from 'jszip';

function storeDiskSyncPlugin(): Plugin {
  return {
    name: 'store-disk-sync-plugin',
    configureServer(server) {
      const rootDir = server.config.root || process.cwd();
      const uploadsDir = path.resolve(rootDir, 'public/uploads');
      const storeDataPath = path.resolve(rootDir, 'src/data/storeData.json');
      const publicStoreDataPath = path.resolve(rootDir, 'public/storeData.json');

      // Ensure public and public/uploads directories exist
      if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
      }

      // Helper to decode base64 and save as file
      const saveBase64Media = (dataUri: string, prefix: string): string => {
        if (!dataUri || typeof dataUri !== 'string') return dataUri;
        if (!dataUri.startsWith('data:')) return dataUri;

        try {
          const matches = dataUri.match(/^data:([A-Za-z-+/]+);base64,(.+)$/);
          if (!matches || matches.length !== 3) return dataUri;

          const mimeType = matches[1];
          const base64Data = matches[2];
          let ext = 'jpg';
          if (mimeType.includes('png')) ext = 'png';
          else if (mimeType.includes('webp')) ext = 'webp';
          else if (mimeType.includes('gif')) ext = 'gif';
          else if (mimeType.includes('mp4')) ext = 'mp4';
          else if (mimeType.includes('webm')) ext = 'webm';
          else if (mimeType.includes('svg')) ext = 'svg';

          const filename = `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}.${ext}`;
          const destPath = path.join(uploadsDir, filename);
          fs.writeFileSync(destPath, Buffer.from(base64Data, 'base64'));

          return `/uploads/${filename}`;
        } catch (err) {
          console.warn('Error saving base64 to disk:', err);
          return dataUri;
        }
      };

      server.middlewares.use(async (req, res, next) => {
        const url = req.url || '';

        // 1. Endpoint: Sync store state and uploaded media directly to disk
        if (url.startsWith('/api/sync-to-disk') && req.method === 'POST') {
          let body = '';
          req.on('data', (chunk) => {
            body += chunk;
          });

          req.on('end', () => {
            try {
              const payload = JSON.parse(body);
              let savedMediaCount = 0;

              // Process products images
              if (Array.isArray(payload.products)) {
                payload.products = payload.products.map((prod: any) => {
                  if (Array.isArray(prod.images) && prod.images.length > 0) {
                    const firstImg = prod.images[0];
                    if (typeof firstImg === 'string' && firstImg.startsWith('data:')) {
                      const localUrl = saveBase64Media(firstImg, `prod_${prod.id || 'item'}`);
                      prod.images = [localUrl];
                      savedMediaCount++;
                    }
                  }
                  return prod;
                });
              }

              // Process hero images/videos
              if (payload.heroConfig) {
                if (payload.heroConfig.fallbackImageUrl?.startsWith('data:')) {
                  payload.heroConfig.fallbackImageUrl = saveBase64Media(
                    payload.heroConfig.fallbackImageUrl,
                    'hero_fallback'
                  );
                  savedMediaCount++;
                }
                if (payload.heroConfig.videoUrl?.startsWith('data:')) {
                  payload.heroConfig.videoUrl = saveBase64Media(
                    payload.heroConfig.videoUrl,
                    'hero_video'
                  );
                  savedMediaCount++;
                }
              }

              // Process site settings
              if (payload.siteSettings) {
                if (payload.siteSettings.ourPromiseImageUrl?.startsWith('data:')) {
                  payload.siteSettings.ourPromiseImageUrl = saveBase64Media(
                    payload.siteSettings.ourPromiseImageUrl,
                    'site_promise'
                  );
                  savedMediaCount++;
                }
              }

              // Process philosophy
              if (payload.philosophyConfig) {
                if (payload.philosophyConfig.craftImageUrl?.startsWith('data:')) {
                  payload.philosophyConfig.craftImageUrl = saveBase64Media(
                    payload.philosophyConfig.craftImageUrl,
                    'philosophy_craft'
                  );
                  savedMediaCount++;
                }
                if (payload.philosophyConfig.promiseImageUrl?.startsWith('data:')) {
                  payload.philosophyConfig.promiseImageUrl = saveBase64Media(
                    payload.philosophyConfig.promiseImageUrl,
                    'philosophy_promise'
                  );
                  savedMediaCount++;
                }
              }

              // Process blog posts
              if (Array.isArray(payload.blogPosts)) {
                payload.blogPosts = payload.blogPosts.map((post: any) => {
                  if (post.image?.startsWith('data:')) {
                    post.image = saveBase64Media(post.image, `blog_${post.id || 'story'}`);
                    savedMediaCount++;
                  }
                  if (Array.isArray(post.additionalImages)) {
                    post.additionalImages = post.additionalImages.map((imgObj: any) => {
                      if (imgObj?.url?.startsWith('data:')) {
                        imgObj.url = saveBase64Media(imgObj.url, `blog_gallery_${post.id || 'img'}`);
                        savedMediaCount++;
                      }
                      return imgObj;
                    });
                  }
                  return post;
                });
              }

              // Process instagram posts
              if (Array.isArray(payload.instagramPosts)) {
                payload.instagramPosts = payload.instagramPosts.map((post: any) => {
                  if (post.imageUrl?.startsWith('data:')) {
                    post.imageUrl = saveBase64Media(post.imageUrl, `journey_img_${post.id || 'post'}`);
                    savedMediaCount++;
                  }
                  if (post.videoUrl?.startsWith('data:')) {
                    post.videoUrl = saveBase64Media(post.videoUrl, `journey_vid_${post.id || 'post'}`);
                    savedMediaCount++;
                  }
                  return post;
                });
              }

              // Process ingredients
              if (Array.isArray(payload.ingredients)) {
                payload.ingredients = payload.ingredients.map((ing: any) => {
                  if (ing.image?.startsWith('data:')) {
                    ing.image = saveBase64Media(ing.image, `ingredient_${ing.id || 'herb'}`);
                    savedMediaCount++;
                  }
                  return ing;
                });
              }

              // Load existing data to merge any missing sections
              let existingData: any = {};
              if (fs.existsSync(storeDataPath)) {
                try {
                  existingData = JSON.parse(fs.readFileSync(storeDataPath, 'utf-8'));
                } catch (_) {}
              }

              const mergedData = {
                ...existingData,
                ...payload,
                products: payload.products ?? existingData.products ?? [],
                heroConfig: payload.heroConfig ?? existingData.heroConfig,
                siteSettings: payload.siteSettings ?? existingData.siteSettings,
                philosophyConfig: payload.philosophyConfig ?? existingData.philosophyConfig,
                ingredients: payload.ingredients ?? existingData.ingredients ?? [],
                blogPosts: payload.blogPosts ?? existingData.blogPosts ?? [],
                instagramPosts: payload.instagramPosts ?? existingData.instagramPosts ?? [],
                reviews: payload.reviews ?? existingData.reviews ?? [],
                coupons: payload.coupons ?? existingData.coupons ?? [],
                lastUpdated: new Date().toISOString(),
              };

              // Write to src/data/storeData.json
              const dataDir = path.dirname(storeDataPath);
              if (!fs.existsSync(dataDir)) {
                fs.mkdirSync(dataDir, { recursive: true });
              }
              fs.writeFileSync(storeDataPath, JSON.stringify(mergedData, null, 2), 'utf-8');

              // Mirror to public/storeData.json
              fs.writeFileSync(publicStoreDataPath, JSON.stringify(mergedData, null, 2), 'utf-8');

              res.setHeader('Content-Type', 'application/json');
              res.statusCode = 200;
              res.end(
                JSON.stringify({
                  success: true,
                  message: `Successfully synchronized ${mergedData.products?.length || 0} products and ${savedMediaCount} media items to project disk.`,
                  savedMediaCount,
                  timestamp: mergedData.lastUpdated,
                  updatedStoreData: mergedData,
                })
              );
            } catch (error: any) {
              console.error('Disk sync error:', error);
              res.setHeader('Content-Type', 'application/json');
              res.statusCode = 500;
              res.end(JSON.stringify({ success: false, error: error?.message || 'Failed to sync to disk' }));
            }
          });
          return;
        }

        // 2. Endpoint: Download complete project codebase as ZIP
        if (url.startsWith('/api/download-project-zip') && (req.method === 'GET' || req.method === 'HEAD')) {
          if (req.method === 'HEAD') {
            res.setHeader('Content-Type', 'application/zip');
            res.setHeader('Content-Disposition', 'attachment; filename="envirve-naturals-full-codebase.zip"');
            res.statusCode = 200;
            res.end();
            return;
          }
          try {
            const zip = new JSZip();

            const addDirToZip = (dir: string) => {
              const items = fs.readdirSync(dir);
              for (const item of items) {
                if (
                  item === 'node_modules' ||
                  item === 'dist' ||
                  item === '.git' ||
                  item === '.cache' ||
                  item === '.tmp' ||
                  item.endsWith('.zip') ||
                  item.endsWith('.log')
                ) {
                  continue;
                }
                const fullPath = path.join(dir, item);
                const relPath = path.relative(rootDir, fullPath);
                const stat = fs.statSync(fullPath);
                if (stat.isDirectory()) {
                  addDirToZip(fullPath);
                } else {
                  zip.file(relPath, fs.readFileSync(fullPath));
                }
              }
            };

            addDirToZip(rootDir);

            const buffer = await zip.generateAsync({
              type: 'nodebuffer',
              compression: 'DEFLATE',
              compressionOptions: { level: 6 },
            });

            res.setHeader('Content-Type', 'application/zip');
            res.setHeader(
              'Content-Disposition',
              `attachment; filename="envirve-naturals-full-codebase-${Date.now()}.zip"`
            );
            res.setHeader('Content-Length', buffer.length.toString());
            res.statusCode = 200;
            res.end(buffer);
          } catch (err: any) {
            console.error('ZIP generation error:', err);
            if (!res.headersSent) {
              res.statusCode = 500;
              res.end('Failed to create ZIP');
            }
          }
          return;
        }

        // 3. Endpoint: Check disk sync status
        if (url.startsWith('/api/disk-status') && req.method === 'GET') {
          let uploadFilesCount = 0;
          if (fs.existsSync(uploadsDir)) {
            uploadFilesCount = fs.readdirSync(uploadsDir).filter((f) => !f.startsWith('.')).length;
          }

          let storeDataExists = false;
          let productsCount = 0;
          let lastUpdated = '';

          if (fs.existsSync(storeDataPath)) {
            try {
              const data = JSON.parse(fs.readFileSync(storeDataPath, 'utf-8'));
              storeDataExists = true;
              productsCount = data.products?.length || 0;
              lastUpdated = data.lastUpdated || '';
            } catch (_) {}
          }

          res.setHeader('Content-Type', 'application/json');
          res.statusCode = 200;
          res.end(
            JSON.stringify({
              storeDataExists,
              productsCount,
              uploadFilesCount,
              lastUpdated,
            })
          );
          return;
        }

        // 4. Endpoint: Direct Media Upload to public/uploads
        if (url.startsWith('/api/upload-media') && req.method === 'POST') {
          let body = '';
          req.on('data', (chunk) => {
            body += chunk;
          });

          req.on('end', () => {
            try {
              const { dataUri, prefix = 'media', filename: customFilename } = JSON.parse(body);
              if (!dataUri || !dataUri.startsWith('data:')) {
                res.setHeader('Content-Type', 'application/json');
                res.statusCode = 400;
                res.end(JSON.stringify({ success: false, error: 'Invalid data URI provided' }));
                return;
              }

              const savedUrl = saveBase64Media(dataUri, prefix);
              res.setHeader('Content-Type', 'application/json');
              res.statusCode = 200;
              res.end(JSON.stringify({ success: true, url: savedUrl }));
            } catch (err: any) {
              console.error('Media upload error:', err);
              res.setHeader('Content-Type', 'application/json');
              res.statusCode = 500;
              res.end(JSON.stringify({ success: false, error: err?.message || 'Failed to upload media' }));
            }
          });
          return;
        }

        // 5. Endpoint: Resend Order Notification Dispatch
        if (url.startsWith('/api/send-resend-notification') && req.method === 'POST') {
          let body = '';
          req.on('data', (chunk) => {
            body += chunk;
          });

          req.on('end', async () => {
            try {
              const payload = JSON.parse(body);
              const order = payload.order;
              const ownerEmail = payload.ownerEmail || 'envirvenaturals@gmail.com';
              const fromEmail = payload.fromEmail || 'Envirve Naturals <onboarding@resend.dev>';

              // Resolve Resend API key
              let apiKey = payload.apiKey || process.env.RESEND_API_KEY;
              if (!apiKey && fs.existsSync(storeDataPath)) {
                try {
                  const sData = JSON.parse(fs.readFileSync(storeDataPath, 'utf-8'));
                  apiKey = sData?.siteSettings?.resendApiKey;
                } catch (_) {}
              }

              if (!apiKey || !apiKey.trim()) {
                res.setHeader('Content-Type', 'application/json');
                res.statusCode = 200;
                res.end(
                  JSON.stringify({
                    success: false,
                    message: 'Resend API key not configured yet. Add your API key in Admin Settings > Resend.',
                  })
                );
                return;
              }

              const itemsList = (order.items || [])
                .map(
                  (item: any) => `
                <tr style="border-bottom: 1px solid #ECE7DA;">
                  <td style="padding: 10px 8px; font-size: 14px; color: #1B3218;">
                    <strong>${item.productName}</strong>
                    ${item.volumeSize ? `<br/><span style="font-size: 12px; color: #6E7D6C;">Size: ${item.volumeSize}</span>` : ''}
                  </td>
                  <td style="padding: 10px 8px; font-family: monospace; font-size: 14px; text-align: center; color: #2D5A27; font-weight: bold;">
                    x${item.quantity}
                  </td>
                  <td style="padding: 10px 8px; font-family: monospace; font-size: 14px; text-align: right; color: #1B3218; font-weight: 600;">
                    Rs. ${(item.price * item.quantity).toLocaleString()}
                  </td>
                </tr>
              `
                )
                .join('');

              const emailHtml = `
                <!DOCTYPE html>
                <html>
                <body style="margin: 0; padding: 24px 10px; background-color: #F5F3EC; font-family: sans-serif; color: #232822;">
                  <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 16px; overflow: hidden; border: 1px solid #E5DFD1;">
                    <div style="background-color: #1C3619; color: #FFFFFF; padding: 28px 24px; text-align: center;">
                      <span style="font-size: 11px; letter-spacing: 0.2em; text-transform: uppercase; color: #A8E3A0; font-weight: 700; display: block; margin-bottom: 6px;">New Customer Order</span>
                      <h1 style="font-family: Georgia, serif; font-size: 26px; margin: 0 0 4px 0;">Envirve Naturals</h1>
                      <p style="font-size: 13px; color: #D5E5D1; margin: 0;">Order #${order.orderNumber} placed</p>
                    </div>
                    <div style="background-color: #EDF6EB; border-bottom: 1px solid #DFEBDC; padding: 14px 20px; text-align: center;">
                      <span style="font-size: 22px; font-weight: bold; font-family: monospace; color: #1C3619;">Rs. ${order.total.toLocaleString()}</span>
                      <span style="display: block; font-size: 12px; color: #4A5B47; margin-top: 2px;">${order.paymentMethod} · ${order.status}</span>
                    </div>
                    <div style="padding: 24px;">
                      <div style="background-color: #FAF9F5; border: 1px solid #ECE7DA; border-radius: 10px; padding: 16px; margin-bottom: 20px;">
                        <h3 style="font-size: 12px; text-transform: uppercase; letter-spacing: 0.1em; color: #2D5A27; margin: 0 0 10px 0;">Customer Information</h3>
                        <p style="margin: 3px 0; font-size: 13px;"><strong>Name:</strong> ${order.customerName}</p>
                        <p style="margin: 3px 0; font-size: 13px;"><strong>Phone:</strong> <a href="tel:${order.customerPhone}" style="color: #2D5A27;">${order.customerPhone}</a></p>
                        <p style="margin: 3px 0; font-size: 13px;"><strong>Email:</strong> ${order.customerEmail || 'Not provided'}</p>
                        <p style="margin: 3px 0; font-size: 13px;"><strong>Address:</strong> ${order.shippingAddress}, ${order.city}</p>
                        ${order.transactionRef ? `<p style="margin: 3px 0; font-size: 13px; color: #D92525;"><strong>JazzCash TID:</strong> ${order.transactionRef}</p>` : ''}
                        ${order.notes ? `<p style="margin: 3px 0; font-size: 13px; font-style: italic;"><strong>Notes:</strong> "${order.notes}"</p>` : ''}
                      </div>
                      <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                        <thead>
                          <tr style="border-bottom: 2px solid #E8E2D5; text-align: left; font-size: 11px; text-transform: uppercase; color: #728070;">
                            <th style="padding: 6px 0;">Item</th>
                            <th style="padding: 6px; text-align: center;">Qty</th>
                            <th style="padding: 6px 0; text-align: right;">Total</th>
                          </tr>
                        </thead>
                        <tbody>
                          ${itemsList}
                        </tbody>
                        <tfoot>
                          <tr>
                            <td colspan="2" style="padding: 8px 0 2px 0; text-align: right; font-size: 13px; color: #6E7D6C;">Subtotal:</td>
                            <td style="padding: 8px 0 2px 0; text-align: right; font-family: monospace; font-size: 13px;">Rs. ${order.subtotal.toLocaleString()}</td>
                          </tr>
                          <tr>
                            <td colspan="2" style="padding: 2px 0; text-align: right; font-size: 13px; color: #6E7D6C;">Delivery:</td>
                            <td style="padding: 2px 0; text-align: right; font-family: monospace; font-size: 13px;">Rs. ${order.deliveryFee.toLocaleString()}</td>
                          </tr>
                          <tr style="border-top: 2px solid #2D5A27;">
                            <td colspan="2" style="padding: 10px 0 0 0; text-align: right; font-size: 15px; font-weight: bold; color: #1B3218;">Total:</td>
                            <td style="padding: 10px 0 0 0; text-align: right; font-family: monospace; font-size: 18px; font-weight: bold; color: #2D5A27;">Rs. ${order.total.toLocaleString()}</td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                    <div style="background-color: #F8F6F0; border-top: 1px solid #ECE7DA; padding: 14px 20px; text-align: center; font-size: 11px; color: #7A8778;">
                      Sent instantly to ${ownerEmail} via Resend.com API integration.
                    </div>
                  </div>
                </body>
                </html>
              `;

              const resendRes = await fetch('https://api.resend.com/emails', {
                method: 'POST',
                headers: {
                  Authorization: `Bearer ${apiKey.trim()}`,
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                  from: fromEmail,
                  to: [ownerEmail],
                  subject: `🌿 New Order #${order.orderNumber} - ${order.customerName} (Rs. ${order.total.toLocaleString()})`,
                  html: emailHtml,
                }),
              });

              const resendData = await resendRes.json();
              if (!resendRes.ok) {
                res.setHeader('Content-Type', 'application/json');
                res.statusCode = 200; // Return soft failure with message
                res.end(
                  JSON.stringify({
                    success: false,
                    message: resendData?.message || 'Resend API returned an error',
                    details: resendData,
                  })
                );
                return;
              }

              res.setHeader('Content-Type', 'application/json');
              res.statusCode = 200;
              res.end(
                JSON.stringify({
                  success: true,
                  id: resendData.id,
                  message: `Order notification delivered to ${ownerEmail} via Resend!`,
                })
              );
            } catch (err: any) {
              console.error('Resend notification dispatch error:', err);
              res.setHeader('Content-Type', 'application/json');
              res.statusCode = 500;
              res.end(JSON.stringify({ success: false, message: err?.message || 'Failed to dispatch via Resend' }));
            }
          });
          return;
        }

        // 6. Endpoint: Direct GitHub Push via Personal Access Token
        if (url.startsWith('/api/github-push') && req.method === 'POST') {
          let body = '';
          req.on('data', (chunk) => {
            body += chunk;
          });

          req.on('end', async () => {
            try {
              const { repo, token, branch = 'main', commitMessage } = JSON.parse(body);

              if (!repo || !token) {
                res.setHeader('Content-Type', 'application/json');
                res.statusCode = 400;
                res.end(JSON.stringify({ success: false, error: 'Repository name and GitHub Token are required.' }));
                return;
              }

              // Clean repository: extract owner/repo
              let cleanRepo = repo.trim();
              cleanRepo = cleanRepo.replace(/^https?:\/\/github\.com\//i, '');
              cleanRepo = cleanRepo.replace(/^git@github\.com:/i, '');
              cleanRepo = cleanRepo.replace(/\.git$/i, '');
              cleanRepo = cleanRepo.replace(/^\/+|\/+$/g, '');

              const parts = cleanRepo.split('/');
              if (parts.length !== 2 || !parts[0] || !parts[1]) {
                res.setHeader('Content-Type', 'application/json');
                res.statusCode = 200;
                res.end(JSON.stringify({
                  success: false,
                  error: `Invalid repository format: "${repo}". Please enter in format "owner/repo" (for example: "yourname/envirve-naturals") without spaces or https://.`
                }));
                return;
              }

              const [owner, repoName] = parts;
              const cleanBranch = (branch || 'main').trim().replace(/^refs\/heads\//, '') || 'main';
              const cleanToken = token.trim();

              const authRemoteUrl = `https://${encodeURIComponent(cleanToken)}@github.com/${owner}/${repoName}.git`;

              const { exec } = await import('child_process');
              const util = await import('util');
              const execAsync = util.promisify(exec);

              // 1. Commit any outstanding unstaged changes
              try {
                await execAsync('git add -A', { cwd: rootDir });
                const msg = commitMessage?.trim() || `Update Envirve Naturals codebase - ${new Date().toISOString()}`;
                await execAsync(`git commit -m "${msg.replace(/"/g, '\\"')}"`, { cwd: rootDir });
              } catch (_) {
                // Working tree clean
              }

              // 2. Ensure current branch matches target branch
              try {
                await execAsync(`git branch -M ${cleanBranch}`, { cwd: rootDir });
              } catch (_) {}

              // 3. Set remote origin
              try {
                await execAsync('git remote remove origin', { cwd: rootDir });
              } catch (_) {}
              await execAsync(`git remote add origin ${authRemoteUrl}`, { cwd: rootDir });

              // 4. Push to remote
              const pushResult = await execAsync(`git push -u origin ${cleanBranch} --force`, {
                cwd: rootDir,
                timeout: 45000,
              });

              // Clean origin remote URL to remove token from config
              try {
                await execAsync(`git remote set-url origin https://github.com/${owner}/${repoName}.git`, { cwd: rootDir });
              } catch (_) {}

              res.setHeader('Content-Type', 'application/json');
              res.statusCode = 200;
              res.end(JSON.stringify({
                success: true,
                message: `Successfully pushed commit to GitHub repository ${owner}/${repoName} on branch ${cleanBranch}!`,
                details: pushResult.stdout || pushResult.stderr || 'Pushed successfully.',
                repoUrl: `https://github.com/${owner}/${repoName}`
              }));
            } catch (err: any) {
              console.error('Direct GitHub push error:', err);
              let safeError = err?.stderr || err?.message || 'Failed to push to GitHub';
              safeError = safeError.replace(/https:\/\/[^@]+@github\.com/g, 'https://***@github.com');

              let hint = 'Please check repository name and token permissions.';
              if (safeError.includes('Repository not found')) {
                hint = 'Repository not found. Create it first on https://github.com/new as a blank repository (no README/license), and verify your token has "repo" permissions.';
              } else if (safeError.includes('Bad credentials') || safeError.includes('Authentication failed')) {
                hint = 'Authentication failed. Generate a Personal Access Token at https://github.com/settings/tokens (classic with "repo" scope, or fine-grained token with Read/Write Repository contents).';
              }

              res.setHeader('Content-Type', 'application/json');
              res.statusCode = 200;
              res.end(JSON.stringify({
                success: false,
                error: safeError,
                hint
              }));
            }
          });
          return;
        }

        next();
      });
    },
  };
}

export default defineConfig(() => {
  return {
    base: './',
    plugins: [react(), tailwindcss(), storeDiskSyncPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
