import rawStoreData from './storeData.json';
import {
  Product,
  HeroConfig,
  SiteSettings,
  PhilosophyConfig,
  Ingredient,
  BlogPost,
  InstagramPost,
  Review,
  Coupon,
} from '../types';

export interface StoreSnapshot {
  lastUpdated?: string;
  products: Product[];
  heroConfig: HeroConfig;
  siteSettings: SiteSettings;
  philosophyConfig: PhilosophyConfig;
  ingredients: Ingredient[];
  blogPosts: BlogPost[];
  instagramPosts: InstagramPost[];
  reviews: Review[];
  coupons: Coupon[];
}

export const defaultStoreData: StoreSnapshot = rawStoreData as unknown as StoreSnapshot;

export const defaultProducts: Product[] = defaultStoreData.products || [];
export const defaultHeroConfig: HeroConfig = defaultStoreData.heroConfig;
export const defaultSiteSettings: SiteSettings = defaultStoreData.siteSettings;
export const defaultPhilosophyConfig: PhilosophyConfig = defaultStoreData.philosophyConfig;
export const defaultIngredients: Ingredient[] = defaultStoreData.ingredients || [];
export const defaultBlogPosts: BlogPost[] = defaultStoreData.blogPosts || [];
export const defaultInstagramPosts: InstagramPost[] = defaultStoreData.instagramPosts || [];
export const defaultReviews: Review[] = defaultStoreData.reviews || [];
export const defaultCoupons: Coupon[] = defaultStoreData.coupons || [];
