import React from 'react';
import { useStore } from '../../context/StoreContext';
import {
  Sparkles,
  Shield,
  HeartHandshake,
  Sprout,
  ArrowRight,
} from 'lucide-react';
import { resolveMediaSrc } from '../../utils/mediaStorage';

export const AboutView: React.FC = () => {
  const {
    philosophyConfig,
    siteSettings,
    setActiveView,
  } = useStore();

  const getPillarIcon = (iconName: string) => {
    switch (iconName) {
      case 'Sprout':
        return <Sprout className="w-6 h-6 text-[#2D5A27]" />;
      case 'HeartHandshake':
        return <HeartHandshake className="w-6 h-6 text-[#2D5A27]" />;
      case 'Shield':
        return <Shield className="w-6 h-6 text-[#2D5A27]" />;
      case 'Sparkles':
      default:
        return <Sparkles className="w-6 h-6 text-[#2D5A27]" />;
    }
  };

  const craftImageSrc =
    resolveMediaSrc(philosophyConfig?.craftImageUrl) ||
    '/src/assets/images/hero_botanical_ritual_1790696451263.jpg';

  const promiseImageSrc =
    resolveMediaSrc(philosophyConfig?.promiseImageUrl) ||
    resolveMediaSrc(siteSettings?.ourPromiseImageUrl) ||
    '/src/assets/images/hero_botanical_ritual_1790696451263.jpg';

  const promiseQuoteText =
    philosophyConfig?.promiseQuote ||
    siteSettings?.ourPromiseQuote ||
    'Care formulated backward from pure botanical wisdom.';

  const pillarsList = Array.isArray(philosophyConfig?.pillars) && philosophyConfig.pillars.length > 0
    ? philosophyConfig.pillars
    : [
        {
          id: 'pillar-1',
          icon: 'Sprout' as const,
          title: 'Nature-Led Formulation',
          desc: 'We formulate backward from nature’s most resilient botanicals, relying on active plant intelligence rather than chemical shortcuts.',
        },
        {
          id: 'pillar-2',
          icon: 'HeartHandshake' as const,
          title: 'Thoughtfully Handcrafted',
          desc: 'Every batch is prepared in limited micro-batches to guarantee freshness, potency, and active botanical vitality.',
        },
        {
          id: 'pillar-3',
          icon: 'Shield' as const,
          title: 'Total Ingredient Transparency',
          desc: 'Zero sulfates, zero synthetic silicones, zero parabens, and zero artificial dyes. Every ingredient is openly disclosed.',
        },
        {
          id: 'pillar-4',
          icon: 'Sparkles' as const,
          title: 'Everyday Mindful Rituals',
          desc: 'Care is the daily rhythm of honoring your body. Our natural textures and botanical aromas turn routine hygiene into moments of peace.',
        },
      ];

  return (
    <div className="bg-[#FAF9F5] min-h-screen py-12 sm:py-16 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* 1. Story Intro */}
        <div className="max-w-3xl mx-auto text-center mb-20">
          <span className="text-[11px] font-sans tracking-[0.3em] uppercase text-[#2D5A27] font-semibold block mb-3">
            {philosophyConfig?.introKicker || 'The Origin of Envirve'}
          </span>
          <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#1B3218] leading-[1.15] mb-6 [text-wrap:balance]">
            {philosophyConfig?.introHeading || 'Rooted in nature. Thoughtfully made for you.'}
          </h1>
          {philosophyConfig?.introQuote && (
            <p className="font-serif italic text-xl text-[#394C36] mb-6">
              {philosophyConfig.introQuote}
            </p>
          )}
          <p className="text-sm sm:text-base text-[#566654] font-light leading-relaxed [text-wrap:balance]">
            {philosophyConfig?.introParagraph ||
              'Envirve Naturals was born out of a yearning for simplicity, truth, and genuine botanical care.'}
          </p>
        </div>

        {/* 2. Cinematic Imagery & Craftsmanship Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center mb-24">
          <div className="group relative rounded-2xl overflow-hidden shadow-md bg-[#ECE7DC] aspect-[4/3]">
            <img
              src={craftImageSrc}
              alt={philosophyConfig?.craftHeading || 'Botanical craftsmanship and natural ingredients'}
              className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-103"
            />
          </div>

          <div className="space-y-6 md:pl-6">
            <span className="text-xs uppercase tracking-[0.25em] font-semibold text-[#2D5A27]">
              {philosophyConfig?.craftSectionTag || 'Our Craftsmanship'}
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#1B3218] leading-tight">
              {philosophyConfig?.craftHeading || 'Slow infusions, unhurried methods.'}
            </h2>
            {philosophyConfig?.craftParagraph1 && (
              <p className="text-xs sm:text-sm text-[#50604E] leading-relaxed">
                {philosophyConfig.craftParagraph1}
              </p>
            )}
            {philosophyConfig?.craftParagraph2 && (
              <p className="text-xs sm:text-sm text-[#50604E] leading-relaxed">
                {philosophyConfig.craftParagraph2}
              </p>
            )}
            <div className="pt-2 flex items-center gap-3">
              <button
                onClick={() => {
                  setActiveView('shop');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="px-6 py-3 bg-[#1F3E1B] text-white text-xs uppercase tracking-widest font-semibold rounded-lg hover:bg-[#2B5226] transition-colors inline-flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <span>{philosophyConfig?.craftButtonText || 'Discover the Formulations'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* 3. The Core Standards / The Envirve Promise */}
        <div className="mb-24 space-y-12">
          {/* Section Header */}
          <div className="max-w-7xl mx-auto border-b border-[#ECE7DA] pb-6">
            <span className="text-xs uppercase tracking-[0.2em] font-semibold text-[#2D5A27] block mb-2">
              {philosophyConfig?.pillarsSectionTag || 'Our Core Standards'}
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#1B3218]">
              {philosophyConfig?.pillarsHeading || 'The Envirve Promise'}
            </h2>
          </div>

          {/* Featured The Envirve Promise Picture & Quote Showcase */}
          <div className="relative group rounded-3xl overflow-hidden shadow-lg aspect-[16/9] sm:aspect-[21/9] bg-[#1B3218]">
            <img
              src={promiseImageSrc}
              alt={philosophyConfig?.pillarsHeading || 'The Envirve Promise'}
              className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-102"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/20" />

            {/* In-Picture Overlay Quote & Tag */}
            <div className="absolute inset-0 p-6 sm:p-10 flex flex-col justify-end text-white max-w-2xl">
              <span className="text-[11px] uppercase tracking-[0.3em] text-[#CFE4CD] font-medium block mb-2">
                Our Sincere Commitment
              </span>
              <h3 className="font-serif italic text-2xl sm:text-3xl md:text-4xl text-[#FAF9F5] leading-snug drop-shadow-sm mb-3">
                “{promiseQuoteText}”
              </h3>
              <p className="text-xs sm:text-sm text-[#D8E6D5] font-light max-w-lg leading-relaxed">
                Every botanical formula is rooted in ancient integrity, unadulterated cold-pressed herbs, and an unwavering respect for your health.
              </p>
            </div>
          </div>

          {/* The 4 Core Standards Pillars Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {pillarsList.map((pillar) => (
              <div
                key={pillar.id}
                className="p-6 bg-white rounded-2xl border border-[#ECE7DA] shadow-xs flex flex-col justify-between hover:border-[#C5DEC0] transition-colors"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-[#EEF5EC] flex items-center justify-center mb-5">
                    {getPillarIcon(pillar.icon)}
                  </div>
                  <h3 className="font-serif text-lg text-[#1B3218] font-medium mb-2.5">
                    {pillar.title}
                  </h3>
                  <p className="text-xs text-[#52634F] leading-relaxed">
                    {pillar.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 4. Ethical Commitment Callout Banner */}
        <div className="p-8 sm:p-12 bg-[#203D1D] rounded-3xl text-white text-center max-w-4xl mx-auto relative overflow-hidden shadow-lg">
          <div className="relative z-10 space-y-4">
            <span className="text-[11px] font-sans tracking-[0.3em] uppercase text-[#B8DBB2] font-semibold block">
              {philosophyConfig?.ethicalKicker || 'Ethical Sourcing & Earth Respect'}
            </span>
            <h3 className="font-serif text-2xl sm:text-3xl font-medium">
              {philosophyConfig?.ethicalHeading || 'Packaged with conscience. Made without compromise.'}
            </h3>
            <p className="text-xs sm:text-sm text-[#D8E6D5] max-w-2xl mx-auto font-light leading-relaxed">
              {philosophyConfig?.ethicalDescription ||
                'We package in amber recyclable glass and reusable aluminum tins whenever possible. Our labels are printed with non-toxic soy inks, and every box is secured with compostable kraft tape.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
