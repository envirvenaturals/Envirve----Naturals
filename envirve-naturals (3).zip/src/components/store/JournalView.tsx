import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  ArrowLeft,
  Clock,
  Calendar,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { resolveMediaSrc } from '../../utils/mediaStorage';

export const JournalView: React.FC = () => {
  const { blogPosts } = useStore();

  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);

  // Selected article
  const selectedPost = blogPosts.find((p) => p.id === selectedPostId) || null;

  // Customers see published articles
  const displayedPosts = blogPosts.filter((p) => p.isPublished);

  // --------------------------------------------------------------------------
  // ARTICLE DETAIL VIEW
  // --------------------------------------------------------------------------
  if (selectedPost) {
    return (
      <div className="bg-[#FAF9F5] min-h-screen py-10 sm:py-16 transition-colors">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Navigation Back */}
          <div className="mb-8">
            <button
              onClick={() => {
                setSelectedPostId(null);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#4A5E46] hover:text-[#1F3D1C] transition-colors group cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
              <span>Back to Botanical Journal</span>
            </button>
          </div>

          <article>
            {/* Article Header Metadata */}
            <header className="space-y-4 mb-8">
              <div className="flex flex-wrap items-center gap-3 text-xs text-[#6A7B68] font-sans">
                <span className="px-3 py-1 bg-[#EEF5EC] text-[#2D5A27] font-semibold uppercase tracking-wider rounded-full">
                  {selectedPost.category}
                </span>
                <span className="flex items-center gap-1 font-mono">
                  <Calendar className="w-3.5 h-3.5" />
                  {selectedPost.date}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1 font-mono">
                  <Clock className="w-3.5 h-3.5" />
                  {selectedPost.readTime}
                </span>
              </div>

              <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#1B3218] leading-[1.18] [text-wrap:balance]">
                {selectedPost.title}
              </h1>

              {selectedPost.author && (
                <p className="text-xs uppercase tracking-widest text-[#72836F] font-medium">
                  By {selectedPost.author}
                </p>
              )}
            </header>

            {/* Featured Hero Cover Image */}
            <div className="relative aspect-[16/9] rounded-2xl overflow-hidden shadow-md bg-[#ECE7DC] mb-3">
              <img
                src={resolveMediaSrc(selectedPost.image)}
                alt={selectedPost.title}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Cover Picture Caption */}
            {selectedPost.imageCaption && (
              <p className="font-serif italic text-xs text-[#6B7968] text-center mb-8">
                {selectedPost.imageCaption}
              </p>
            )}

            {/* Short Excerpt Lead Paragraph */}
            {selectedPost.excerpt && (
              <p className="font-serif italic text-base sm:text-lg text-[#253922] leading-relaxed mb-8 pb-6 border-b border-[#ECE7DA] font-light">
                {selectedPost.excerpt}
              </p>
            )}

            {/* Body Content */}
            <div className="prose prose-stone max-w-none text-[#334230] leading-relaxed space-y-5 text-sm sm:text-base font-light">
              {(selectedPost.content || '').split('\n\n').map((paragraph, idx) => {
                if (paragraph.startsWith('### ')) {
                  return (
                    <h3
                      key={idx}
                      className="font-serif text-xl sm:text-2xl text-[#1B3218] font-semibold pt-4"
                    >
                      {paragraph.replace('### ', '')}
                    </h3>
                  );
                }
                if (paragraph.startsWith('> ')) {
                  return (
                    <blockquote
                      key={idx}
                      className="border-l-2 border-[#2D5A27] pl-4 italic text-[#243B21] my-4 font-serif text-base"
                    >
                      {paragraph.replace('> ', '')}
                    </blockquote>
                  );
                }
                return <p key={idx}>{paragraph}</p>;
              })}
            </div>

            {/* Additional Story Pictures Gallery if present */}
            {selectedPost.additionalImages && selectedPost.additionalImages.length > 0 && (
              <div className="mt-12 pt-8 border-t border-[#ECE7DA] space-y-6">
                <div className="flex items-center justify-between">
                  <h4 className="font-serif text-lg font-bold text-[#1B3218] flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#2D5A27]" />
                    <span>Ritual Imagery & Field Chronicle</span>
                  </h4>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {selectedPost.additionalImages.map((img, i) => (
                    <div key={img.id || i} className="group/item space-y-2">
                      <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-[#ECE7DC] shadow-xs">
                        <img
                          src={resolveMediaSrc(img.url)}
                          alt={img.alt || img.caption || 'Journal photo'}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover/item:scale-103"
                        />
                      </div>
                      {img.caption && (
                        <p className="font-serif italic text-xs text-[#61725E] leading-snug">
                          {img.caption}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Bottom Story Footer */}
            <div className="mt-14 pt-6 border-t border-[#ECE7DA] flex items-center justify-between">
              <button
                onClick={() => {
                  setSelectedPostId(null);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#4A5E46] hover:text-[#1F3D1C] transition-colors group cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
                <span>Return to Botanical Archive</span>
              </button>
            </div>
          </article>
        </div>
      </div>
    );
  }

  // --------------------------------------------------------------------------
  // JOURNAL ARCHIVE CATALOG VIEW
  // --------------------------------------------------------------------------
  return (
    <div className="bg-[#FAF9F5] min-h-screen py-14 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Title */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-[11px] font-sans tracking-[0.3em] uppercase text-[#2D5A27] font-semibold block mb-2">
            The Botanical Archive
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#1B3218] mb-4">
            The Envirve Journal
          </h1>
          <p className="text-sm text-[#5B6B58] font-light leading-relaxed">
            Explorations into traditional herbalism, mindful scalp rituals, sustainable harvesting, and natural beauty philosophy.
          </p>
        </div>

        {/* Grid of Journal Articles */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayedPosts.map((post) => (
            <div
              key={post.id}
              onClick={() => {
                setSelectedPostId(post.id);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="group bg-white rounded-2xl border border-[#ECE7DA] hover:border-[#2D5A27] overflow-hidden shadow-xs hover:shadow-md transition-all duration-300 flex flex-col justify-between cursor-pointer"
            >
              <div>
                {/* Article Image Container */}
                <div className="relative aspect-[16/10] bg-[#F4F1EA] overflow-hidden">
                  <img
                    src={resolveMediaSrc(post.image)}
                    alt={post.title}
                    className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                    loading="lazy"
                  />
                </div>

                <div className="p-6">
                  <div className="flex items-center justify-between text-xs text-[#7B8B79] mb-2 font-sans">
                    <span className="uppercase tracking-[0.2em] font-medium text-[#2D5A27]">
                      {post.category}
                    </span>
                    <span>{post.readTime}</span>
                  </div>

                  <h3 className="font-serif text-xl text-[#1B3218] group-hover:text-[#2D5A27] transition-colors leading-snug mb-3">
                    {post.title}
                  </h3>

                  <p className="text-xs text-[#5C6A5A] leading-relaxed line-clamp-3">
                    {post.excerpt}
                  </p>
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="p-4 bg-[#FAF9F5] border-t border-[#ECE7DA] flex items-center justify-between text-xs text-[#2D5A27] font-semibold tracking-wider">
                <span className="uppercase text-[#6F816E]">{post.date}</span>
                <span className="inline-flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                  <span>Read Story</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
