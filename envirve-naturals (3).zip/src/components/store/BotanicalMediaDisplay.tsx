import React, { useState, useEffect } from 'react';
import { InstagramPost } from '../../types';
import { resolveMediaSrc, rehydrateMediaUrl } from '../../utils/mediaStorage';

interface BotanicalMediaDisplayProps {
  post: InstagramPost;
  className?: string;
  autoPlay?: boolean;
}

export const BotanicalMediaDisplay: React.FC<BotanicalMediaDisplayProps> = ({
  post,
  className = 'w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-108',
  autoPlay = true,
}) => {
  const [videoError, setVideoError] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [rehydratedVideoSrc, setRehydratedVideoSrc] = useState<string>('');

  const rawVideo = (post.videoUrl || '').trim();
  const rawImage = (post.imageUrl || '').trim();

  useEffect(() => {
    let isCancelled = false;
    setVideoError(false);

    if (rawVideo.startsWith('/uploads/') || rawVideo.startsWith('http') || rawVideo.startsWith('data:')) {
      setRehydratedVideoSrc(rawVideo);
    } else if (rawVideo.startsWith('idb://')) {
      rehydrateMediaUrl(rawVideo)
        .then((liveUrl) => {
          if (!isCancelled && liveUrl && !liveUrl.startsWith('idb://')) {
            setRehydratedVideoSrc(liveUrl);
          }
        })
        .catch(() => {
          if (!isCancelled) setVideoError(true);
        });
    } else {
      setRehydratedVideoSrc('');
    }

    return () => {
      isCancelled = true;
    };
  }, [rawVideo]);

  const hasPlayableVideo = Boolean(
    !videoError &&
    rehydratedVideoSrc &&
    (post.mediaType === 'video' ||
      rawVideo.endsWith('.mp4') ||
      rawVideo.endsWith('.webm') ||
      rawVideo.includes('/uploads/journey_vid') ||
      rawVideo.startsWith('idb://'))
  );

  const resolvedImageSrc = resolveMediaSrc(rawImage);

  // If valid video available and hasn't errored
  if (hasPlayableVideo) {
    return (
      <video
        src={rehydratedVideoSrc}
        poster={resolvedImageSrc}
        autoPlay={autoPlay}
        loop
        muted
        playsInline
        onError={() => setVideoError(true)}
        className={className}
      />
    );
  }

  // Display photo / poster
  const displaySrc = resolvedImageSrc || rehydratedVideoSrc;
  if (displaySrc && !imageError) {
    return (
      <img
        src={displaySrc}
        alt={post.caption || 'Envirve Naturals Botanical Journey'}
        onError={() => setImageError(true)}
        className={className}
      />
    );
  }

  // Graceful botanical branding fallback if image link fails or is empty
  return (
    <div className="w-full h-full bg-[#1C3619] flex flex-col items-center justify-center p-4 text-center text-white select-none">
      <span className="font-serif italic text-base text-[#D5E5D1]">Envirve Naturals</span>
      <span className="text-[11px] text-[#A8C7A3] mt-1.5 font-medium line-clamp-3 leading-snug max-w-xs">
        {post.caption || 'Pure herbal botanicals & mindful daily care.'}
      </span>
      <span className="text-[9px] uppercase tracking-widest text-[#82A87D] mt-2 font-mono">
        Botanical Journey
      </span>
    </div>
  );
};
