import { Order } from '../types';

export function formatResendOrderNotificationHtml(
  order: Order,
  storeName = 'Envirve Naturals'
): string {
  const itemsList = order.items
    .map(
      (item) => `
    <tr style="border-bottom: 1px solid #ECE7DA;">
      <td style="padding: 12px 8px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; color: #1B3218;">
        <strong>${item.productName}</strong>
        ${item.volumeSize ? `<br/><span style="font-size: 12px; color: #6E7D6C;">Size: ${item.volumeSize}</span>` : ''}
      </td>
      <td style="padding: 12px 8px; font-family: monospace; font-size: 14px; text-align: center; color: #2D5A27; font-weight: bold;">
        x${item.quantity}
      </td>
      <td style="padding: 12px 8px; font-family: monospace; font-size: 14px; text-align: right; color: #1B3218; font-weight: 600;">
        Rs. ${(item.price * item.quantity).toLocaleString()}
      </td>
    </tr>
  `
    )
    .join('');

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>New Order #${order.orderNumber} - Resend Notification</title>
</head>
<body style="margin: 0; padding: 24px 10px; background-color: #F5F3EC; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #232822;">
  <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border-radius: 16px; overflow: hidden; border: 1px solid #E5DFD1; box-shadow: 0 4px 14px rgba(0,0,0,0.05);">
    
    <!-- Top Alert Banner -->
    <div style="background-color: #1C3619; color: #FFFFFF; padding: 28px 24px; text-align: center;">
      <span style="font-size: 11px; letter-spacing: 0.25em; text-transform: uppercase; color: #A8E3A0; font-weight: 700; display: block; margin-bottom: 6px;">
        ⚡ Instant Resend Order Alert
      </span>
      <h1 style="font-family: Georgia, serif; font-size: 26px; margin: 0 0 6px 0; font-weight: normal; color: #FAF8F5;">
        ${storeName}
      </h1>
      <p style="font-size: 13px; color: #D5E5D1; margin: 0;">
        You received a new customer order on your website!
      </p>
    </div>

    <!-- Quick Revenue Banner -->
    <div style="background-color: #EDF6EB; border-bottom: 1px solid #DFEBDC; padding: 16px 24px; text-align: center;">
      <span style="font-size: 12px; text-transform: uppercase; letter-spacing: 0.1em; color: #2D5A27; font-weight: 600; display: block;">Total Revenue</span>
      <span style="font-size: 26px; font-weight: bold; font-family: monospace; color: #1C3619;">
        Rs. ${order.total.toLocaleString()}
      </span>
      <span style="display: block; font-size: 12px; color: #52634F; margin-top: 4px;">
        Order #${order.orderNumber} · ${order.status.toUpperCase()} · ${order.paymentMethod}
      </span>
    </div>

    <!-- Main Content -->
    <div style="padding: 24px;">
      
      <!-- Customer Information Card -->
      <div style="background-color: #FAF9F5; border: 1px solid #ECE7DA; border-radius: 12px; padding: 18px; margin-bottom: 22px;">
        <h3 style="font-size: 12px; letter-spacing: 0.15em; text-transform: uppercase; color: #2D5A27; margin: 0 0 12px 0; font-weight: 700;">
          Customer & Delivery Address
        </h3>
        <table style="width: 100%; font-size: 13px; border-collapse: collapse;">
          <tr>
            <td style="padding: 5px 0; color: #6D7B6B; width: 120px; font-weight: 500;">Customer:</td>
            <td style="padding: 5px 0; font-weight: 600; color: #1B3218;">${order.customerName}</td>
          </tr>
          <tr>
            <td style="padding: 5px 0; color: #6D7B6B; font-weight: 500;">Phone:</td>
            <td style="padding: 5px 0; font-weight: 600;">
              <a href="tel:${order.customerPhone}" style="color: #2D5A27; text-decoration: none;">${order.customerPhone}</a>
            </td>
          </tr>
          <tr>
            <td style="padding: 5px 0; color: #6D7B6B; font-weight: 500;">Email:</td>
            <td style="padding: 5px 0; color: #1B3218;">
              ${order.customerEmail ? `<a href="mailto:${order.customerEmail}" style="color: #2D5A27;">${order.customerEmail}</a>` : '<span style="color: #9AA697; font-style: italic;">Not provided</span>'}
            </td>
          </tr>
          <tr>
            <td style="padding: 5px 0; color: #6D7B6B; font-weight: 500;">Address:</td>
            <td style="padding: 5px 0; color: #1B3218; line-height: 1.45;">
              ${order.shippingAddress}, <strong>${order.city}</strong>${order.postalCode ? ' - ' + order.postalCode : ''}
            </td>
          </tr>
          <tr>
            <td style="padding: 5px 0; color: #6D7B6B; font-weight: 500;">Payment Method:</td>
            <td style="padding: 5px 0; color: #1B3218; font-weight: 600;">
              ${order.paymentMethod} (${order.paymentStatus})
            </td>
          </tr>
          ${order.transactionRef ? `
          <tr>
            <td style="padding: 5px 0; color: #6D7B6B; font-weight: 500;">JazzCash TID:</td>
            <td style="padding: 5px 0; font-family: monospace; font-weight: bold; color: #D92525;">
              ${order.transactionRef}
            </td>
          </tr>` : ''}
          ${order.notes ? `
          <tr>
            <td style="padding: 5px 0; color: #6D7B6B; font-weight: 500; vertical-align: top;">Notes:</td>
            <td style="padding: 5px 0; font-style: italic; color: #3A4A36;">
              "${order.notes}"
            </td>
          </tr>` : ''}
        </table>
      </div>

      <!-- Items Ordered Table -->
      <div style="margin-bottom: 22px;">
        <h3 style="font-size: 12px; letter-spacing: 0.15em; text-transform: uppercase; color: #2D5A27; margin: 0 0 12px 0; font-weight: 700;">
          Ordered Items (${order.items.reduce((s, i) => s + i.quantity, 0)} Units)
        </h3>
        <table style="width: 100%; border-collapse: collapse;">
          <thead>
            <tr style="border-bottom: 2px solid #E8E2D5; text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: 0.1em; color: #728070;">
              <th style="padding: 8px 8px 8px 0;">Item Description</th>
              <th style="padding: 8px; text-align: center;">Qty</th>
              <th style="padding: 8px 0 8px 8px; text-align: right;">Total</th>
            </tr>
          </thead>
          <tbody>
            ${itemsList}
          </tbody>
          <tfoot>
            <tr>
              <td colspan="2" style="padding: 10px 8px 4px 0; font-size: 13px; text-align: right; color: #6E7D6C;">Subtotal:</td>
              <td style="padding: 10px 0 4px 8px; font-family: monospace; font-size: 13px; text-align: right; color: #1B3218;">Rs. ${order.subtotal.toLocaleString()}</td>
            </tr>
            ${order.discountAmount ? `
            <tr>
              <td colspan="2" style="padding: 4px 8px 4px 0; font-size: 13px; text-align: right; color: #2D5A27;">Coupon Discount:</td>
              <td style="padding: 4px 0 4px 8px; font-family: monospace; font-size: 13px; text-align: right; color: #2D5A27;">-Rs. ${order.discountAmount.toLocaleString()}</td>
            </tr>` : ''}
            <tr>
              <td colspan="2" style="padding: 4px 8px 4px 0; font-size: 13px; text-align: right; color: #6E7D6C;">Shipping Fee:</td>
              <td style="padding: 4px 0 4px 8px; font-family: monospace; font-size: 13px; text-align: right; color: #1B3218;">Rs. ${order.deliveryFee.toLocaleString()}</td>
            </tr>
            <tr style="border-top: 2px solid #2D5A27;">
              <td colspan="2" style="padding: 12px 8px 0 0; font-size: 15px; font-weight: bold; text-align: right; color: #1B3218;">Grand Total:</td>
              <td style="padding: 12px 0 0 8px; font-family: monospace; font-size: 18px; font-weight: bold; text-align: right; color: #2D5A27;">Rs. ${order.total.toLocaleString()}</td>
            </tr>
          </tfoot>
        </table>
      </div>

    </div>

    <!-- Footer -->
    <div style="background-color: #F8F6F0; border-top: 1px solid #ECE7DA; padding: 16px 24px; text-align: center; font-size: 11px; color: #879484;">
      <p style="margin: 0 0 4px 0;">Delivered instantly to envirvenaturals@gmail.com via Resend.com API integration.</p>
      <p style="margin: 0; font-weight: 600; color: #2D5A27;">Envirve Naturals · nature . care . you .</p>
    </div>

  </div>
</body>
</html>
  `.trim();
}

/**
 * Triggers order notification to the store owner via Resend (https://resend.com)
 */
export async function sendResendOrderNotification(
  order: Order,
  options?: {
    apiKey?: string;
    ownerEmail?: string;
    fromEmail?: string;
  }
): Promise<{ success: boolean; message: string; id?: string }> {
  try {
    const res = await fetch('/api/send-resend-notification', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        order,
        apiKey: options?.apiKey,
        ownerEmail: options?.ownerEmail || 'envirvenaturals@gmail.com',
        fromEmail: options?.fromEmail || 'Envirve Naturals <onboarding@resend.dev>',
      }),
    });

    const data = await res.json();
    return data;
  } catch (err: any) {
    console.warn('Resend notification notice:', err);
    return {
      success: false,
      message: err?.message || 'Could not reach Resend dispatch endpoint',
    };
  }
}
